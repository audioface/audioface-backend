package face;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hair {

private Double bald;
private Boolean invisible;
private List<HairColor> hairColor = null;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Double getBald() {
return bald;
}

public void setBald(Double bald) {
this.bald = bald;
}

public Boolean getInvisible() {
return invisible;
}

public void setInvisible(Boolean invisible) {
this.invisible = invisible;
}

public List<HairColor> getHairColor() {
return hairColor;
}

public void setHairColor(List<HairColor> hairColor) {
this.hairColor = hairColor;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}