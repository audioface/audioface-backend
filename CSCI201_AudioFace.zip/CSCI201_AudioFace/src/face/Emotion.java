package face;

import java.util.HashMap;
import java.util.Map;

public class Emotion {

private Double contempt;
private Integer surprise;
private Double happiness;
private Double neutral;
private Integer sadness;
private Integer disgust;
private Integer anger;
private Integer fear;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Double getContempt() {
return contempt;
}

public void setContempt(Double contempt) {
this.contempt = contempt;
}

public Integer getSurprise() {
return surprise;
}

public void setSurprise(Integer surprise) {
this.surprise = surprise;
}

public Double getHappiness() {
return happiness;
}

public void setHappiness(Double happiness) {
this.happiness = happiness;
}

public Double getNeutral() {
return neutral;
}

public void setNeutral(Double neutral) {
this.neutral = neutral;
}

public Integer getSadness() {
return sadness;
}

public void setSadness(Integer sadness) {
this.sadness = sadness;
}

public Integer getDisgust() {
return disgust;
}

public void setDisgust(Integer disgust) {
this.disgust = disgust;
}

public Integer getAnger() {
return anger;
}

public void setAnger(Integer anger) {
this.anger = anger;
}

public Integer getFear() {
return fear;
}

public void setFear(Integer fear) {
this.fear = fear;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}