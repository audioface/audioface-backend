

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

import com.google.gson.Gson;

import PlaylistPOJOs.Example;

/**
 * Servlet implementation class GetTracksFromPlaylistJSON
 */
@WebServlet("/GetTracksFromPlaylistJSON")
public class GetTracksFromPlaylistJSON extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public static Vector<String> getTracks(String playlistID) {
		Vector<String> trackIdVect = new Vector<String>();
		//String apiURL = "https://api.spotify.com/v1/playlists/"+playlistID+"/tracks?market=US&limit=10&offset=0";
		String apiURL = "https://api.spotify.com/v1/playlists/21THa8j9TaSGuXYNBU5tsC/tracks?market=US&limit=10&offset=0";
		String basicAuth = "BQC1ghUnbFqOXH026xCPQ0kfN9nMePnh6ri29lN7bNbp8soTcqd5SKLSv4MKLG9CnihOFP085vuaLBZDdjzLhGjJ7rn-j92TNH_IG8vaHET-Q6VUAltvJArpymFS7LcVpDGeVQYdCHbPz6RI36rQChxEJjIKdvMgzrJQ3fTXJDMLhtJOhaRpZPXaL7onDh5ldneAKIEa_QtTHJvKxtGMwtwTmjWK3xcnE9K4zcQP8wbKFItKCnHBIelkymeC4VsNEtUivZjKuxuc7mY";
		URL weatherURL;
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("GET");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example queryPOJO = gson.fromJson(list.toString(), PlaylistPOJOs.Example.class);
	        List<PlaylistPOJOs.Item> myTrackList = queryPOJO.getItems();
	        for(int i=0; i<myTrackList.size(); i++) {
	        	//System.out.println(myTrackList.get(i).getTrack().getName() + " by " + myTrackList.get(i).getTrack().getArtists().get(0).getName());
	        	trackIdVect.add(myTrackList.get(i).getTrack().getUri());
	        }
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		//return a vector of ID strings for all the songs
		return trackIdVect;
	}

}
