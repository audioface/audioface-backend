package face;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FaceAttributes {

private Makeup makeup;
private FacialHair facialHair;
private String gender;
private List<Accessory> accessories = null;
private Blur blur;
private HeadPose headPose;
private Double smile;
private String glasses;
private Hair hair;
private Emotion emotion;
private Exposure exposure;
private Occlusion occlusion;
private Noise noise;
private Integer age;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Makeup getMakeup() {
return makeup;
}

public void setMakeup(Makeup makeup) {
this.makeup = makeup;
}

public FacialHair getFacialHair() {
return facialHair;
}

public void setFacialHair(FacialHair facialHair) {
this.facialHair = facialHair;
}

public String getGender() {
return gender;
}

public void setGender(String gender) {
this.gender = gender;
}

public List<Accessory> getAccessories() {
return accessories;
}

public void setAccessories(List<Accessory> accessories) {
this.accessories = accessories;
}

public Blur getBlur() {
return blur;
}

public void setBlur(Blur blur) {
this.blur = blur;
}

public HeadPose getHeadPose() {
return headPose;
}

public void setHeadPose(HeadPose headPose) {
this.headPose = headPose;
}

public Double getSmile() {
return smile;
}

public void setSmile(Double smile) {
this.smile = smile;
}

public String getGlasses() {
return glasses;
}

public void setGlasses(String glasses) {
this.glasses = glasses;
}

public Hair getHair() {
return hair;
}

public void setHair(Hair hair) {
this.hair = hair;
}

public Emotion getEmotion() {
return emotion;
}

public void setEmotion(Emotion emotion) {
this.emotion = emotion;
}

public Exposure getExposure() {
return exposure;
}

public void setExposure(Exposure exposure) {
this.exposure = exposure;
}

public Occlusion getOcclusion() {
return occlusion;
}

public void setOcclusion(Occlusion occlusion) {
this.occlusion = occlusion;
}

public Noise getNoise() {
return noise;
}

public void setNoise(Noise noise) {
this.noise = noise;
}

public Integer getAge() {
return age;
}

public void setAge(Integer age) {
this.age = age;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}