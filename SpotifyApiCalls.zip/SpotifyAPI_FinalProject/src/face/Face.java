package face;

import java.util.HashMap;
import java.util.Map;

public class Face {

private FaceRectangle faceRectangle;
private FaceAttributes faceAttributes;
private String faceId;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public FaceRectangle getFaceRectangle() {
return faceRectangle;
}

public void setFaceRectangle(FaceRectangle faceRectangle) {
this.faceRectangle = faceRectangle;
}

public FaceAttributes getFaceAttributes() {
return faceAttributes;
}

public void setFaceAttributes(FaceAttributes faceAttributes) {
this.faceAttributes = faceAttributes;
}

public String getFaceId() {
return faceId;
}

public void setFaceId(String faceId) {
this.faceId = faceId;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}