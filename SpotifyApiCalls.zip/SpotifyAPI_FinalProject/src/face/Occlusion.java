package face;

import java.util.HashMap;
import java.util.Map;

public class Occlusion {

private Boolean eyeOccluded;
private Boolean mouthOccluded;
private Boolean foreheadOccluded;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Boolean getEyeOccluded() {
return eyeOccluded;
}

public void setEyeOccluded(Boolean eyeOccluded) {
this.eyeOccluded = eyeOccluded;
}

public Boolean getMouthOccluded() {
return mouthOccluded;
}

public void setMouthOccluded(Boolean mouthOccluded) {
this.mouthOccluded = mouthOccluded;
}

public Boolean getForeheadOccluded() {
return foreheadOccluded;
}

public void setForeheadOccluded(Boolean foreheadOccluded) {
this.foreheadOccluded = foreheadOccluded;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}