package face;

import java.util.HashMap;
import java.util.Map;

public class Makeup {

private Boolean eyeMakeup;
private Boolean lipMakeup;
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public Boolean getEyeMakeup() {
return eyeMakeup;
}

public void setEyeMakeup(Boolean eyeMakeup) {
this.eyeMakeup = eyeMakeup;
}

public Boolean getLipMakeup() {
return lipMakeup;
}

public void setLipMakeup(Boolean lipMakeup) {
this.lipMakeup = lipMakeup;
}

public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}