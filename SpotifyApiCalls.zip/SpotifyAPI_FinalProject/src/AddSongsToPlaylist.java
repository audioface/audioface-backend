

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import AddSongPOJOs.Example;

/**
 * Servlet implementation class AddSongsToPlaylist
 */
@WebServlet("/AddSongsToPlaylist")
public class AddSongsToPlaylist extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public static void addSongs(String playlistID, Vector<String> playlistURIs) {
		String apiURL = "https://api.spotify.com/v1/playlists/"+playlistID+"/tracks?uris=";
		for(int i=0; i<playlistURIs.size(); i++) {
			String _uri = playlistURIs.get(i);
			String myURI = _uri.replaceAll(":", "%3A");
			System.out.println(myURI);
//			char[] uriChar = playlistURIs.get(i).toCharArray();
//			for(int k=0; k<uriChar.length; k++) {
//				if(String.valueOf(uriChar[k]) != ":") myURI += uriChar[k];
//				else myURI += "%3A";
//			}
			if(i == playlistURIs.size()-1) apiURL+=myURI;
			else apiURL+=myURI +"%2C";
		}
		String basicAuth = "BQC1ghUnbFqOXH026xCPQ0kfN9nMePnh6ri29lN7bNbp8soTcqd5SKLSv4MKLG9CnihOFP085vuaLBZDdjzLhGjJ7rn-j92TNH_IG8vaHET-Q6VUAltvJArpymFS7LcVpDGeVQYdCHbPz6RI36rQChxEJjIKdvMgzrJQ3fTXJDMLhtJOhaRpZPXaL7onDh5ldneAKIEa_QtTHJvKxtGMwtwTmjWK3xcnE9K4zcQP8wbKFItKCnHBIelkymeC4VsNEtUivZjKuxuc7mY";
		URL weatherURL;
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("POST");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example addSongPOJO = gson.fromJson(list.toString(), Example.class);
	        //print out the snapshot id
			System.out.println(addSongPOJO.getSnapshotId());
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
	}
}
