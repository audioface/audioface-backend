

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import QueryPOJOs.Example;
import QueryPOJOs.Item;

/**
 * Servlet implementation class ParseQueryJSON
 */
@WebServlet("/ParseQueryJSON")
public class ParseQueryJSON extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public static String parseQueryJSON(String query) {
		//String apiURL = "https://api.spotify.com/v1/search?q="+query+"&type=playlist&limit=1&offset=0";
		String apiURL = "https://api.spotify.com/v1/search?q=doom%20metal&type=playlist&limit=1&offset=0";
		String basicAuth = "BQC1ghUnbFqOXH026xCPQ0kfN9nMePnh6ri29lN7bNbp8soTcqd5SKLSv4MKLG9CnihOFP085vuaLBZDdjzLhGjJ7rn-j92TNH_IG8vaHET-Q6VUAltvJArpymFS7LcVpDGeVQYdCHbPz6RI36rQChxEJjIKdvMgzrJQ3fTXJDMLhtJOhaRpZPXaL7onDh5ldneAKIEa_QtTHJvKxtGMwtwTmjWK3xcnE9K4zcQP8wbKFItKCnHBIelkymeC4VsNEtUivZjKuxuc7mY";
		URL weatherURL;
		String playlistID = "";
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("GET");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example queryPOJO = gson.fromJson(list.toString(), Example.class);
	        playlistID = queryPOJO.getPlaylists().getItems().get(0).getId();
	        /*
	        testing:
	        List<Item> myPlaylists = queryPOJO.getPlaylists().getItems();
	        for(int i=0; i<myPlaylists.size(); i++) {
	        	System.out.println(myPlaylists.get(i).getName());
	        }
	        */
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		return playlistID;
	}

}
