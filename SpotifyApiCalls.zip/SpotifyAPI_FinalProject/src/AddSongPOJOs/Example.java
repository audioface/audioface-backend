package AddSongPOJOs;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Example {
	@SerializedName("snapshot_id")
	@Expose
	private String snapshotId;

	public String getSnapshotId() {
	return snapshotId;
	}

	public void setSnapshotId(String snapshotId) {
	this.snapshotId = snapshotId;
	}
}
