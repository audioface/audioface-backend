package file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import CreatePlaylistPOJOs.Example;

/**
 * Servlet implementation class CreatePlaylist
 */
@WebServlet("/CreatePlaylist")
public class CreatePlaylist extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//get spotify id
		String spotifyid = (String) session.getAttribute("spotifyid");
		//get token
		String token = (String) session.getAttribute("accessToken");
		String title = (String) session.getAttribute("emotion");
		String description = "Playlist made by AudioFace!";
		boolean isPublic = true;
		String isGuest = (String) session.getAttribute("isGuest");
		//if null then use AudioFace account
		String newPlaylistID = "";
		if(isGuest.equals("true")) {
			newPlaylistID = createPlaylist(title, description, isPublic, token, "o36hhe9kvejnv4qtphids8erl");
		}
		else {
			newPlaylistID = createPlaylist(title, description, isPublic, token, spotifyid);
		}
		session.setAttribute("newPlaylistID", newPlaylistID);
		//send the playlist ID's to get tracks servlet
		System.out.println("Created a playlist");
		RequestDispatcher rd = request.getRequestDispatcher("/AddSongsToPlaylist");
		rd.forward(request, response);
	}
	
    public String createPlaylist(String myTitle, String myDescription, boolean isPublic, String token, String spotifyid) {
    	//format the Request Body
    	String formatting = "{";
    	String nameString = "\"name\":\"" + myTitle + "\",";
    	String descripString = "\"description\":\"" + myDescription + "\",";
    	String isPublicString = "";
    	if(isPublic) isPublicString = "true";
    	else isPublicString = "false";
    	String publicString = "\"public\":"+ isPublicString +"}";
    	formatting = formatting + nameString + descripString + publicString;
    	System.out.println(formatting);
    	//now make the API Call
		String apiURL = "https://api.spotify.com/v1/users/"+spotifyid+"/playlists";
		String basicAuth = token;
		URL weatherURL;
		String newPlaylistID = "";
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("POST");
	        //send the json as body of the request
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            OutputStream outputStream = myConnection.getOutputStream();
            outputStream.write(formatting.getBytes("UTF-8"));
            outputStream.close();
            //now read the data
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example newPlaylistPOJO = gson.fromJson(list.toString(), Example.class);
	        newPlaylistID = newPlaylistPOJO.getId();
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		
		return newPlaylistID;
    }
}
