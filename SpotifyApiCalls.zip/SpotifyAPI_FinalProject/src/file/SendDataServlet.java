package file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.google.gson.Gson;

import PlaylistPOJOs.Example;

/**
 * Servlet implementation class SendDataServlet
 */
@WebServlet("/SendDataServlet")
public class SendDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static String jsonString;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Get called");
		HttpSession session = request.getSession();
		String title = (String) session.getAttribute("emotion");
		String newPlaylistID = (String) session.getAttribute("newPlaylistID");
		String token = (String) session.getAttribute("accessToken");
		Vector<String> tracks = getTracks(newPlaylistID, token);
		//SendDataServlet.jsonString += formatJson(title, tracks);
		String jsonString = formatJson(title, tracks);
		System.out.println(jsonString);
		response.getWriter().write(jsonString);
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	public Vector<String> getTracks(String playlistID, String token){
		Vector<String> trackIdVect = new Vector<String>();
		String apiURL = "https://api.spotify.com/v1/playlists/"+playlistID+"/tracks?market=US&limit=12&offset=0";
		String basicAuth = token;
		URL weatherURL;
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("GET");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example queryPOJO = gson.fromJson(list.toString(), PlaylistPOJOs.Example.class);
	        List<PlaylistPOJOs.Item> myTrackList = queryPOJO.getItems();
	        for(int i=0; i<myTrackList.size(); i++) {
	        	trackIdVect.add(myTrackList.get(i).getTrack().getName() + " by " + myTrackList.get(i).getTrack().getArtists().get(0).getName());
	        }
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		//return a vector of ID strings for all the songs
		for(int i=0; i<trackIdVect.size(); i++) {
			System.out.println(trackIdVect.get(i));
		}
		return trackIdVect;
	}
	
	public String formatJson(String title, Vector<String> tracks) {
		String toReturn = "";
		toReturn = title+"~~";
		for(int i=0; i<tracks.size(); i++) {
			toReturn += tracks.get(i) + "~~";
		}
		return toReturn;
	}

}
