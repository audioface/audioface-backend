package file;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;

/**
 * Servlet implementation class HandleImage
 */
@WebServlet("/HandleImage")
@MultipartConfig
public class HandleImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HandleImage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Post called");

		// Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		String count = "";
		String fileName = "";
		String userid = "";
		String accessToken = "";
		String refreshToken = "";
		String email = "";
		String isGuest = "";
		if(isMultipart == true) {
			try {
		        List<FileItem> items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(new ServletRequestContext(request));
		        for (FileItem item : items) {
		            if (item.isFormField()) {
		                // Process regular form field (input type="text|radio|checkbox|etc", select, etc).
		                String fieldName = item.getFieldName();
		                if(fieldName.equals("counter")) {
		                	String fieldValue = item.getString();
		                	count = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("isGuest")) {
		                	String fieldValue = item.getString();
		                	isGuest = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("email")) {
		                	String fieldValue = item.getString();
		                	email = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("photo")) {
		                	BufferedImage img = ImageIO.read(item.getInputStream());
		                	fileName = "/Users/b_reel/Desktop/AudioFace/photo"+count+".jpg";
		                	File file = new File(fileName);
		                	ImageIO.write(img, "jpeg", file);
		                }
		                if(fieldName.equals("userid")) {
		                	String fieldValue = item.getString();
		                	userid = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("accessToken")) {
		                	String fieldValue = item.getString();
		                	accessToken = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("refreshToken")) {
		                	String fieldValue = item.getString();
		                	refreshToken = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		            } else {
		                // Process form file field (input type="file").
		                String fieldName = item.getFieldName();
		                InputStream fileContent = item.getInputStream();
		                System.out.println(fieldName + ": " + fileContent);
		            }
		        }
		    } 
			catch (FileUploadException e) {
		       throw new ServletException("Cannot parse multipart request.", e);
			}
		
		 	//go to GetEmotion and parse emotion
			HttpSession session = request.getSession();
			session.setAttribute("isGuest", isGuest);
			session.setAttribute("filePath", fileName);
			session.setAttribute("userid", userid);
			session.setAttribute("accessToken", accessToken);
			session.setAttribute("refreshToken", refreshToken);
			session.setAttribute("email", email);
			//send email if not guest
			if(isGuest == "false") createThreads(userid);
	    	RequestDispatcher rd = request.getRequestDispatcher("/GetEmotion");
	    	rd.forward(request, response);
		}
	}
	
	protected void createThreads(String userid) {
        // get all the friends email of the user
        Connection conn = null;
        PreparedStatement ps = null;
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/Audioface?user=root&password=brandon8");
            ps = conn.prepareStatement("SELECT friend2 FROM friendships WHERE friend1 = ?");
            ps.setString(1, userid); // set first variable in prepared statement
            
            ResultSet rs = ps.executeQuery();
            
            List<String> myFriends = new ArrayList<String>();
            while(rs.next()) {
                // add all the friend2 ids to a list
                myFriends.add(rs.getString("friend2"));
                
                ps = conn.prepareStatement("SELECT email FROM user WHERE userid = ?");
                ps.setString(1, rs.getString("friend2"));
                
                ResultSet foundEmails = ps.executeQuery();
                myFriends.add(foundEmails.getString("email"));
            }
            
            // loop through the list of emails and create a thread for each friend
            // send the email on each thread and then immediately make it go to sleep afterwards
            for (int i = 0; i < myFriends.size(); i++) {
                // create a thread for this friend's email
                EmailThread email = new EmailThread(myFriends.get(i));
                email.start();
            }
        }
        catch (SQLException sqle) {
            System.out.println ("before sqle: "+ sqle.getMessage());
        } 
        catch(ClassNotFoundException cnfe) {
            System.out.println("cnfe: "+ cnfe.getMessage());
        }
        finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
                System.out.print("hello");
            }
            catch (SQLException sqle) {
                System.out.println("sqle: "+sqle.getMessage());
            }
        }
    }
}
