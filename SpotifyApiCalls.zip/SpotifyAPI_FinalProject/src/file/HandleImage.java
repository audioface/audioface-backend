package file;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.tomcat.util.http.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.disk.DiskFileItemFactory;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.apache.tomcat.util.http.fileupload.servlet.ServletRequestContext;


/**
 * Servlet implementation class HandleImage
 */
@WebServlet("/HandleImage")
@MultipartConfig
public class HandleImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HandleImage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Post called");

		// Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		String count = "";
		String fileName = "";
		String userid = "";
		String accessToken = "";
		String refreshToken = "";
		String email = "";
		if(isMultipart == true) {
			try {
		        List<FileItem> items = new ServletFileUpload(new DiskFileItemFactory()).parseRequest(new ServletRequestContext(request));
		        for (FileItem item : items) {
		            if (item.isFormField()) {
		                // Process regular form field (input type="text|radio|checkbox|etc", select, etc).
		                String fieldName = item.getFieldName();
		                if(fieldName.equals("counter")) {
		                	String fieldValue = item.getString();
		                	count = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("email")) {
		                	String fieldValue = item.getString();
		                	email = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("photo")) {
		                	BufferedImage img = ImageIO.read(item.getInputStream());
		                	fileName = "/Users/b_reel/Desktop/AudioFace/photo"+count+".jpg";
		                	File file = new File(fileName);
		                	ImageIO.write(img, "jpeg", file);
		                }
		                if(fieldName.equals("userid")) {
		                	String fieldValue = item.getString();
		                	userid = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("accessToken")) {
		                	String fieldValue = item.getString();
		                	accessToken = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		                if(fieldName.equals("refreshToken")) {
		                	String fieldValue = item.getString();
		                	refreshToken = fieldValue;
		                	System.out.println(fieldName + ": " + fieldValue);
		                }
		            } else {
		                // Process form file field (input type="file").
		                String fieldName = item.getFieldName();
		                InputStream fileContent = item.getInputStream();
		                System.out.println(fieldName + ": " + fileContent);
		            }
		        }
		    } 
			catch (FileUploadException e) {
		       throw new ServletException("Cannot parse multipart request.", e);
			}
		 	//go to GetEmotion and parse emotion
			HttpSession session = request.getSession();
			session.setAttribute("filePath", fileName);
			session.setAttribute("userid", userid);
			session.setAttribute("accessToken", accessToken);
			session.setAttribute("refreshToken", refreshToken);
			session.setAttribute("email", email);
	    	RequestDispatcher rd = request.getRequestDispatcher("/GetEmotion");
	    	rd.forward(request, response);
		}

	}
}
