package file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import AddSongPOJOs.Example;

/**
 * Servlet implementation class AddSongsToPlaylist
 */
@WebServlet("/AddSongsToPlaylist")
public class AddSongsToPlaylist extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//get token
		String token = (String) session.getAttribute("accessToken");
		String newPlaylistID = (String) session.getAttribute("newPlaylistID");
		Vector<String> trackMasterList = (Vector<String>) session.getAttribute("trackMasterList");
		Vector<String> track2add = new Vector<String>();
		String isGuest = (String) session.getAttribute("isGuest");
		System.out.println("*******");
		System.out.println(isGuest);
		System.out.println("*******");
		//if guest then only get 3 songs
		if(isGuest.equals("true")) {
			//pick random songs
			for(int i=0; i<3; i++) {
				int index = (int) (Math.random() * (trackMasterList.size()));
				track2add.add(trackMasterList.get(index));
				trackMasterList.remove(index);
			}
		}
		else {
			//pick random songs
			for(int i=0; i<12; i++) {
				int index = (int) (Math.random() * (trackMasterList.size()));
				track2add.add(trackMasterList.get(index));
				trackMasterList.remove(index);
			}
		}
		//then add them
		addSongs(newPlaylistID, track2add, token);
		System.out.println("Added the songs!");
		session.setAttribute("track2add", track2add);
		RequestDispatcher rd = request.getRequestDispatcher("/SendDataServlet");
		rd.forward(request, response);
	}
	
	public void addSongs(String playlistID, Vector<String> playlistURIs, String token) {
		String apiURL = "https://api.spotify.com/v1/playlists/"+playlistID+"/tracks?uris=";
		for(int i=0; i<playlistURIs.size(); i++) {
			String _uri = playlistURIs.get(i);
			String myURI = _uri.replaceAll(":", "%3A");
			System.out.println(myURI);
			if(i == playlistURIs.size()-1) apiURL+=myURI;
			else apiURL+= myURI +"%2C";
		}
		String formatting = "";
		String basicAuth = token;
		URL weatherURL;
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Content-Length", "0");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("POST");
	        //send the json as body of the request
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            OutputStream outputStream = myConnection.getOutputStream();
            outputStream.write(formatting.getBytes("UTF-8"));
            outputStream.close();
            //read in the data
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example addSongPOJO = gson.fromJson(list.toString(), Example.class);
	        //print out the snapshot id
			System.out.println(addSongPOJO.getSnapshotId());
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
	}
}
