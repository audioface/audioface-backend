package file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.google.gson.Gson;

import UserInfoPOJO.Example;

/**
 * Servlet implementation class GetUserInformation
 */
@WebServlet("/GetUserInformation")
public class GetUserInformation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//get token
		String token = (String) session.getAttribute("accessToken");
		String spotifyid = getUserID(token);
		session.setAttribute("spotifyid", spotifyid);
		//get the ID!
		System.out.println("Got spotify ID!");
		RequestDispatcher rd = request.getRequestDispatcher("/CreatePlaylist");
		rd.forward(request, response);
	}
	
	public String getUserID(String token) {
		String userid = "";
		String apiURL = "https://api.spotify.com/v1/me";
		String basicAuth = token;
		URL weatherURL;
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("GET");
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example userPOJO = gson.fromJson(list.toString(), UserInfoPOJO.Example.class);
	        userid = userPOJO.getId();
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		return userid;
	}

}
