package UserInfoPOJO;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Example {

@SerializedName("birthdate")
@Expose
private String birthdate;
@SerializedName("country")
@Expose
private String country;
@SerializedName("display_name")
@Expose
private String displayName;
@SerializedName("email")
@Expose
private String email;
@SerializedName("external_urls")
@Expose
private ExternalUrls externalUrls;
@SerializedName("followers")
@Expose
private Followers followers;
@SerializedName("href")
@Expose
private String href;
@SerializedName("id")
@Expose
private String id;
@SerializedName("images")
@Expose
private List<Image> images = null;
@SerializedName("product")
@Expose
private String product;
@SerializedName("type")
@Expose
private String type;
@SerializedName("uri")
@Expose
private String uri;

public String getBirthdate() {
return birthdate;
}

public void setBirthdate(String birthdate) {
this.birthdate = birthdate;
}

public String getCountry() {
return country;
}

public void setCountry(String country) {
this.country = country;
}

public String getDisplayName() {
return displayName;
}

public void setDisplayName(String displayName) {
this.displayName = displayName;
}

public String getEmail() {
return email;
}

public void setEmail(String email) {
this.email = email;
}

public ExternalUrls getExternalUrls() {
return externalUrls;
}

public void setExternalUrls(ExternalUrls externalUrls) {
this.externalUrls = externalUrls;
}

public Followers getFollowers() {
return followers;
}

public void setFollowers(Followers followers) {
this.followers = followers;
}

public String getHref() {
return href;
}

public void setHref(String href) {
this.href = href;
}

public String getId() {
return id;
}

public void setId(String id) {
this.id = id;
}

public List<Image> getImages() {
return images;
}

public void setImages(List<Image> images) {
this.images = images;
}

public String getProduct() {
return product;
}

public void setProduct(String product) {
this.product = product;
}

public String getType() {
return type;
}

public void setType(String type) {
this.type = type;
}

public String getUri() {
return uri;
}

public void setUri(String uri) {
this.uri = uri;
}

}