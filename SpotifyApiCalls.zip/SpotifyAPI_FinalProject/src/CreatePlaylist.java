

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import CreatePlaylistPOJOs.Example;

/**
 * Servlet implementation class CreatePlaylist
 */
@WebServlet("/CreatePlaylist")
public class CreatePlaylist extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public static String createPlaylist(String myTitle, String myDescription, boolean isPublic) {
    	//format the Request Body
    	String formatting = "{";
    	String nameString = "\"name\":\"" + myTitle + "\",";
    	String descripString = "\"description\":\"" + myDescription + "\",";
    	String isPublicString = "";
    	if(isPublic) isPublicString = "true";
    	else isPublicString = "false";
    	String publicString = "\"public\":"+ isPublicString +"}";
    	formatting = formatting + nameString + descripString + publicString;
    	System.out.println(formatting);
    	//now make the API Call
		String apiURL = "https://api.spotify.com/v1/users/1224271886/playlists";
		String basicAuth = "BQC1ghUnbFqOXH026xCPQ0kfN9nMePnh6ri29lN7bNbp8soTcqd5SKLSv4MKLG9CnihOFP085vuaLBZDdjzLhGjJ7rn-j92TNH_IG8vaHET-Q6VUAltvJArpymFS7LcVpDGeVQYdCHbPz6RI36rQChxEJjIKdvMgzrJQ3fTXJDMLhtJOhaRpZPXaL7onDh5ldneAKIEa_QtTHJvKxtGMwtwTmjWK3xcnE9K4zcQP8wbKFItKCnHBIelkymeC4VsNEtUivZjKuxuc7mY";
		URL weatherURL;
		String newPlaylistID = "";
		try {
			weatherURL = new URL(apiURL);
			StringBuilder list = new StringBuilder();
	        HttpURLConnection myConnection = (HttpURLConnection)weatherURL.openConnection();
	        myConnection.setRequestProperty ("Authorization", "Bearer "+basicAuth);
	        myConnection.setRequestProperty("Content-Type", "application/json");
	        myConnection.setRequestProperty("Accept", "application/json");
	        myConnection.setRequestMethod("POST");
	        //send the json as body of the request
            myConnection.setDoInput(true);
            myConnection.setDoOutput(true);
            OutputStream outputStream = myConnection.getOutputStream();
            outputStream.write(formatting.getBytes("UTF-8"));
            outputStream.close();
            //now read the data
	        InputStreamReader myISR = new InputStreamReader(myConnection.getInputStream());
	        BufferedReader in = new BufferedReader(myISR);
	        String inputLine = in.readLine();
	        while(inputLine != null) {
	        	list.append(inputLine);
	        	//read in next line
	        	inputLine = in.readLine();
	        }
	        in.close();
			//parse the new JSON string from the weather API
	        Gson gson = new Gson();
	        Example newPlaylistPOJO = gson.fromJson(list.toString(), Example.class);
	        newPlaylistID = newPlaylistPOJO.getId();
		} catch (MalformedURLException me) {
			System.out.println("me: "+me.getMessage());
		} catch (IOException ioe) {
			System.out.println("ioe: "+ioe.getMessage());
		}
		
		return newPlaylistID;
    }
}
