import java.util.Vector;

public class main {

	public static void main(String[] args) {
		//search for a playlist based on query
		String playlistID = ParseQueryJSON.parseQueryJSON("");
		System.out.println(playlistID);
		//now get all the song IDs from the playlist we searched for
		Vector<String> listOfSongIDs = GetTracksFromPlaylistJSON.getTracks(playlistID);
		for(int i=0; i<listOfSongIDs.size(); i++) {
			System.out.println(listOfSongIDs.get(i));
		}
		//create a new playlist with relevant info
		String title = "Happy";
		String description = "Playlist made by AudioFace!";
		boolean isPublic = true;
		String newPlaylistID = CreatePlaylist.createPlaylist(title, description, isPublic);
		System.out.println(newPlaylistID);
		//now add the songs to that playlist;
		AddSongsToPlaylist.addSongs(newPlaylistID, listOfSongIDs);
		//add picture to that playlist
		
	}

}
