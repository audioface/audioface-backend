import java.util.Vector;

import file.AddSongsToPlaylist;
import file.CoverImageServlet;
import file.CreatePlaylist;
import file.GetTracksFromPlaylistJSON;
import file.ParseQueryJSON;

public class main {

	public static void main(String[] args) {
		/*
		String token = "BQBoLHIsOsCD8CqCkJ_GnrUzFzDIP1KkSWJuw22tngjttfYGB_7ol0qN8e2e5jRNLKeR_9wTiHDfdJPKPCstnt-lCczrlLreAwwrbzwcuZIeYAn7Zh8vOuda8seRRpZs3ulLWi71UI8_xl-zZ0mVDHAASZzenzaraZxfA4V9es3Vi37fIqQ0p42YdD3dpluSrdET4MdYoJNIdRsSegONL34grG1qfLZFTpljqSL0u762qJxWzRqe9yEprjYGHgTa4MNAK9_Y4akEnCU";
		//search for a playlist based on query
		String playlistID = ParseQueryJSON.parseQueryJSON("", token);
		System.out.println(playlistID);
		//now get all the song IDs from the playlist we searched for
		Vector<String> listOfSongIDs = GetTracksFromPlaylistJSON.getTracks(playlistID, token);
		for(int i=0; i<listOfSongIDs.size(); i++) {
			System.out.println(listOfSongIDs.get(i));
		}
		//create a new playlist with relevant info
		String title = "Happy";
		String description = "Playlist made by AudioFace!";
		boolean isPublic = true;
		String newPlaylistID = CreatePlaylist.createPlaylist(title, description, isPublic, token);
		System.out.println(newPlaylistID);
		//now add the songs to that playlist;
		AddSongsToPlaylist.addSongs(newPlaylistID, listOfSongIDs, token);
		//add picture to that playlist
		CoverImageServlet.updateCoverImage(newPlaylistID, token);
		*/
	}

}
